package com.xa.qyw.entiy;

public class Departments {
	
	private int id;
	private int hospitalId;
	private String departmentsName;
	private String departmentPhone;
	private String departmentIntro;
	
	public Departments() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getHospitalId() {
		return hospitalId;
	}

	public void setHospitalId(int hospitalId) {
		this.hospitalId = hospitalId;
	}

	public String getDepartmentsName() {
		return departmentsName;
	}

	public void setDepartmentsName(String departmentsName) {
		this.departmentsName = departmentsName;
	}

	public String getDepartmentPhone() {
		return departmentPhone;
	}

	public void setDepartmentPhone(String departmentPhone) {
		this.departmentPhone = departmentPhone;
	}

	public String getDepartmentIntro() {
		return departmentIntro;
	}

	public void setDepartmentIntro(String departmentIntro) {
		this.departmentIntro = departmentIntro;
	}

	

}
