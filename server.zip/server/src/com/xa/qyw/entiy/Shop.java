package com.xa.qyw.entiy;

import java.util.List;

public class Shop {
		
	private List<ShopType> listType;

	public Shop() {
		super();
	}

	public List<ShopType> getListType() {
		return listType;
	}

	public void setListType(List<ShopType> listType) {
		this.listType = listType;
	}
	
	
}
