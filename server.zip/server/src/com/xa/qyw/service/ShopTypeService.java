package com.xa.qyw.service;

import java.util.List;

import com.xa.qyw.entiy.ShopType;

public interface ShopTypeService {

	public List<ShopType> getAllType();
}
