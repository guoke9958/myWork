package com.xa.qyw.service;

import com.xa.qyw.entiy.FeedBack;


public interface FeedBackService {
	
	public int addFeedBack(FeedBack feedback);
}
