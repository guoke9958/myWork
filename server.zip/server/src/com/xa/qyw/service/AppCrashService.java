package com.xa.qyw.service;

import com.xa.qyw.entiy.AppCrash;


public interface AppCrashService {
	
	public void insertAppCrash(AppCrash crash);
}
