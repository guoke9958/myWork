package com.xa.qyw.service;

import com.xa.qyw.entiy.OrderMsg;

public interface OrderMsgService {
	
	public void addOrderMsg(OrderMsg msg);

}
