package com.xa.qyw.utils;

public class ConstantUtil {
	
	public static String PARTNER_KEY = "k0aslk543l7543l80sdlo234ldas0912";

}
