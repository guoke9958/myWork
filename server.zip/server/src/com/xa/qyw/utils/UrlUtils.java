package com.xa.qyw.utils;

public class UrlUtils {
	
	/**
	 * �û�ͼ���ϴ���ַ
	 */
	public static final String DOWNLOAD_USER_PHOTO = "userphoto/";
	
	/**
	 * APP���ص�ַ
	 */
	public static final String DOWNLOAD_APP_FILE = "/download/app/";
	
	/**
	 * Video�ϴ���ַ
	 */
	public static final String DOWNLOAD_VIDEO_FILE = "video/";
	
	
	/**
	 * Video Image�ϴ���ַ
	 */
	public static final String DOWNLOAD_VIDEO_IMAGE_FILE = "videoimage/";
	
}
