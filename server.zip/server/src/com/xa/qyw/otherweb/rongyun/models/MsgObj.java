package com.xa.qyw.otherweb.rongyun.models;

public class MsgObj {
	private String content;
	private String objectName;

	public String getObjectName() {
		return objectName;
	}

	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public MsgObj() {
		super();
	}
}
