package com.xa.qyw.dao;

import com.xa.qyw.entiy.AppCrash;

public interface AppCrashDao {
	
	public void insertAppCrash(AppCrash crash);

}
