package com.xa.qyw.dao;

import java.util.List;

import com.xa.qyw.entiy.ShopType;

public interface TypeDao {
	
	public List<ShopType> getAllType();

}
