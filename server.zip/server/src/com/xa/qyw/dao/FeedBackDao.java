package com.xa.qyw.dao;

import com.xa.qyw.entiy.FeedBack;

public interface FeedBackDao {
	
	public int addFeedBack(FeedBack feedback);

}
