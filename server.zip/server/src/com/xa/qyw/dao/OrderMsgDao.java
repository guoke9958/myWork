package com.xa.qyw.dao;

import com.xa.qyw.entiy.OrderMsg;

public interface OrderMsgDao {

	public void addOrderMsg(OrderMsg msg);
	
}
